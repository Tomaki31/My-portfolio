﻿namespace FileSharingSystemLAN.L79
{
    partial class Form79
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.UploadBtn = new System.Windows.Forms.Button();
            this.SelectFileBtn = new System.Windows.Forms.Button();
            this.ReciveBtn = new System.Windows.Forms.Button();
            this.SelectFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.показатьПапкуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьПапкуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.labelPort = new System.Windows.Forms.Label();
            this.PortBox = new System.Windows.Forms.TextBox();
            this.labelIP = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IPBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.FolderBtn = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // UploadBtn
            // 
            this.UploadBtn.Location = new System.Drawing.Point(12, 224);
            this.UploadBtn.Name = "UploadBtn";
            this.UploadBtn.Size = new System.Drawing.Size(86, 31);
            this.UploadBtn.TabIndex = 0;
            this.UploadBtn.Text = "Отправить";
            this.UploadBtn.UseVisualStyleBackColor = true;
            this.UploadBtn.Click += new System.EventHandler(this.UploadBtn_Click);
            // 
            // SelectFileBtn
            // 
            this.SelectFileBtn.Location = new System.Drawing.Point(12, 179);
            this.SelectFileBtn.Name = "SelectFileBtn";
            this.SelectFileBtn.Size = new System.Drawing.Size(86, 39);
            this.SelectFileBtn.TabIndex = 1;
            this.SelectFileBtn.Text = "Выбрать файл";
            this.SelectFileBtn.UseVisualStyleBackColor = true;
            this.SelectFileBtn.Click += new System.EventHandler(this.SelectFileBtn_Click);
            // 
            // ReciveBtn
            // 
            this.ReciveBtn.Location = new System.Drawing.Point(297, 175);
            this.ReciveBtn.Name = "ReciveBtn";
            this.ReciveBtn.Size = new System.Drawing.Size(86, 47);
            this.ReciveBtn.TabIndex = 2;
            this.ReciveBtn.Text = "Получить файл";
            this.ReciveBtn.UseVisualStyleBackColor = true;
            this.ReciveBtn.Click += new System.EventHandler(this.ReciveBtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(393, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.показатьПапкуToolStripMenuItem,
            this.выбратьПапкуToolStripMenuItem,
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Файл";
            // 
            // показатьПапкуToolStripMenuItem
            // 
            this.показатьПапкуToolStripMenuItem.Name = "показатьПапкуToolStripMenuItem";
            this.показатьПапкуToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.показатьПапкуToolStripMenuItem.Text = "Папка для файлов";
            this.показатьПапкуToolStripMenuItem.Click += new System.EventHandler(this.показатьПапкуToolStripMenuItem_Click);
            // 
            // выбратьПапкуToolStripMenuItem
            // 
            this.выбратьПапкуToolStripMenuItem.Name = "выбратьПапкуToolStripMenuItem";
            this.выбратьПапкуToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.выбратьПапкуToolStripMenuItem.Text = "Выбрать папку";
            this.выбратьПапкуToolStripMenuItem.Click += new System.EventHandler(this.выбоатьПапкуToolStripMenuItem_Click);
            // 
            // папкаВКоторуУстановленаПрограммаToolStripMenuItem
            // 
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem.Name = "папкаВКоторуУстановленаПрограммаToolStripMenuItem";
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem.Text = "Путь к EXE файлу программы ";
            this.папкаВКоторуУстановленаПрограммаToolStripMenuItem.Click += new System.EventHandler(this.папкаВКоторуУстановленаПрограммаToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Файл не выбран";
            // 
            // labelPort
            // 
            this.labelPort.AutoSize = true;
            this.labelPort.Location = new System.Drawing.Point(254, 24);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new System.Drawing.Size(75, 13);
            this.labelPort.TabIndex = 5;
            this.labelPort.Text = "Введите порт";
            // 
            // PortBox
            // 
            this.PortBox.Location = new System.Drawing.Point(257, 40);
            this.PortBox.Name = "PortBox";
            this.PortBox.Size = new System.Drawing.Size(100, 20);
            this.PortBox.TabIndex = 6;
            this.PortBox.Text = "8989";
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(257, 89);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(59, 13);
            this.labelIP.TabIndex = 7;
            this.labelIP.Text = "Твой айпи";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Твой локальный IP:";
            // 
            // IPBox
            // 
            this.IPBox.Location = new System.Drawing.Point(13, 39);
            this.IPBox.Name = "IPBox";
            this.IPBox.Size = new System.Drawing.Size(100, 20);
            this.IPBox.TabIndex = 9;
            this.IPBox.Text = "127.0.0.1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Введите IP клиента";
            // 
            // FolderBtn
            // 
            this.FolderBtn.Location = new System.Drawing.Point(297, 224);
            this.FolderBtn.Name = "FolderBtn";
            this.FolderBtn.Size = new System.Drawing.Size(86, 28);
            this.FolderBtn.TabIndex = 11;
            this.FolderBtn.Text = "Папка";
            this.FolderBtn.UseVisualStyleBackColor = true;
            this.FolderBtn.Click += new System.EventHandler(this.FolderBtn_Click);
            // 
            // Form79
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(393, 261);
            this.Controls.Add(this.FolderBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.IPBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelIP);
            this.Controls.Add(this.PortBox);
            this.Controls.Add(this.labelPort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReciveBtn);
            this.Controls.Add(this.SelectFileBtn);
            this.Controls.Add(this.UploadBtn);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form79";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Share79";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UploadBtn;
        private System.Windows.Forms.Button SelectFileBtn;
        private System.Windows.Forms.Button ReciveBtn;
        private System.Windows.Forms.FolderBrowserDialog SelectFolder;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem показатьПапкуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выбратьПапкуToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelPort;
        private System.Windows.Forms.TextBox PortBox;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IPBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button FolderBtn;
        private System.Windows.Forms.ToolStripMenuItem папкаВКоторуУстановленаПрограммаToolStripMenuItem;
    }
}

