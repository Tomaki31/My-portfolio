﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileSharingSystemLAN.L79
{
    public partial class Form79 : Form
    {
        
        OpenFileDialog ofd = null;
        string _filePath = "";
        string _fileContent = "";
        static string hostName = Dns.GetHostName();
#pragma warning disable CS0618 // Тип или член устарел
        static string myIP =Dns.GetHostByName(hostName).AddressList[0].ToString();   
#pragma warning restore CS0618 // Тип или член устарел
        private TcpListener _listener;
        bool active = true;
        
       
         
        
        public Form79()
        {
            InitializeComponent();
            
            _listener = new TcpListener(IPAddress.Any, Convert.ToInt32(PortBox.Text));
            labelIP.Text = myIP;

        }
        
        private void RunClientReciver()
        {
          while (true)
            {
                TcpClient tcpClient = _listener.AcceptTcpClient();
                Thread localThread = new Thread(new ParameterizedThreadStart(Interact));              
                localThread.Start(tcpClient);
            }
        }
        private void Interact(object obj)
        {
            TcpClient tcpClient = (TcpClient)obj;

            string data = string.Empty;

            StreamWriter NetworkStreamWriter = new StreamWriter(tcpClient.GetStream(), Encoding.UTF8);
            StreamReader NetworkStreamReader = new StreamReader(tcpClient.GetStream(), Encoding.UTF8);
            while(!NetworkStreamReader.EndOfStream)
            {
                data = NetworkStreamReader.ReadLine();
                string filename = data.Split('\\')[0];
                data = data.Split('*')[1];               
                File.WriteAllBytes(filename, Convert.FromBase64String(data));              
                string sourcePath = Properties.Settings.Default.ProgrammPath;
                string targetPath = Properties.Settings.Default.FolderPath;

                string sourceFile = Path.Combine(sourcePath, filename);
                string destFile = Path.Combine(targetPath, filename);

                if (!Directory.Exists(targetPath))
                {
                    Directory.CreateDirectory(targetPath);
                }

                File.Move(sourceFile, destFile);
                
            }
        }
        void ShowFolder(string line)
        {
            Process.Start(new ProcessStartInfo { FileName = "explorer", Arguments = $"/n , /select , {line}" });
        }

      

      
        private void выбоатьПапкуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelectFolder.ShowDialog();
            
            Properties.Settings.Default.FolderPath = SelectFolder.SelectedPath;
            
            Properties.Settings.Default.Save();
            
            
           
        }

        private void показатьПапкуToolStripMenuItem_Click(object sender, EventArgs e)
        {
           ShowFolder(Properties.Settings.Default.FolderPath);
        }

        private void SelectFileBtn_Click(object sender, EventArgs e)
        {
            ofd = new OpenFileDialog();
            if(ofd.ShowDialog()==DialogResult.OK)
            {
                _filePath = ofd.FileName;
                label1.Text = ofd.SafeFileName + $"\\{ ofd.SafeFileName.Split('.')[1]}";
            }
        }
        
        private void UploadBtn_Click(object sender, EventArgs e)
        {
            Text = "Подключение к клиенту...";

            TcpClient client = new TcpClient();
            client.Connect(IPBox.Text, Convert.ToInt32(PortBox.Text));

            Text = "Подключено.";

            StreamWriter NetworkWriter = new StreamWriter(client.GetStream(), Encoding.UTF8);

            byte[] filebuffer = File.ReadAllBytes(_filePath); 
            //File.ReadAllBytes(_filePath); - изначально , только файлы , но не папки

            string base64encodestr = Convert.ToBase64String(filebuffer);
            _fileContent = base64encodestr;

            Text = "Отправка файла...";

            NetworkWriter.Write($"{ofd.SafeFileName}\\* {_fileContent}");

            Text = "Отправлено.";

            Thread.Sleep(850);

            NetworkWriter.Close();
            client.Close();

            Text = "Отправить файл";
        }

        private void FolderBtn_Click(object sender, EventArgs e)
        {
            ShowFolder(Properties.Settings.Default.FolderPath);
        }
        
        private void ReciveBtn_Click(object sender, EventArgs e)
        {              
            _listener.Start();          
            RunClientReciver();                       
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void папкаВКоторуУстановленаПрограммаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelectFolder.ShowDialog();

            Properties.Settings.Default.ProgrammPath = SelectFolder.SelectedPath;

            Properties.Settings.Default.Save();
        }
    }
}
