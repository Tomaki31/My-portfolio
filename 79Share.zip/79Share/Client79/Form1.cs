﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;


namespace Client79
{
    public partial class Form1 : Form
    {
        private TcpListener _listener;
        public Form1()
        {
            InitializeComponent();        
            _listener = new TcpListener(IPAddress.Any, 8989);
        }

        private void RunClientReciver()
        {
            while (true)
            {
                TcpClient tcpClient = _listener.AcceptTcpClient();
                Thread localThread = new Thread(new ParameterizedThreadStart(Interact));
                localThread.Start(tcpClient);
            }
        }
        private void Interact(object obj)
        {
            TcpClient tcpClient = (TcpClient)obj;

            string data = string.Empty;

            StreamWriter NetworkStreamWriter = new StreamWriter(tcpClient.GetStream(), Encoding.UTF8);
            StreamReader NetworkStreamReader = new StreamReader(tcpClient.GetStream(), Encoding.UTF8);
            while (!NetworkStreamReader.EndOfStream)
            {
                data = NetworkStreamReader.ReadLine();
                string filename = data.Split('\\')[0];
                data = data.Split('*')[1];
                File.WriteAllBytes(filename, Convert.FromBase64String(data));
            }
        }
        private void StartBtn_Click(object sender, EventArgs e)
        {
            _listener.Start();
            RunClientReciver();
        }
    }
}
